# Interface-1.3-inch-OLED-Display-with-Nodemcu-Esp8266
How to print simple text using 1.3 inch OLED Display.
Install Required Library: 
  1.SH110X
  2.Adafruit_GFX
  3.u8glib

Connection
OLED Display 	Nodemcu		Arduino Uno
VDD/VCC		    3.3v		  3.3v
GNS		        GND		    GND
SCK		        D1		    A5
SDA		        D2		    A4

